
document.getElementById("btn_serch").onclick = function () {
    if ( document.getElementById("icon_serch").className == "fa-solid fa-chevron-down")
    {
        document.getElementById("serch_form").style.opacity = 0;
        document.getElementById("serch_form").style.visibility = "hidden";
        setTimeout(function () {
            document.getElementById("icon_serch").className = "fa-solid fa-chevron-down fa-rotate-90";
            document.getElementById("under_list").style.height = "60px";
        } , 400)
    }
    else
    {
        document.getElementById("icon_serch").className = "fa-solid fa-chevron-down";
        document.getElementById("under_list").style.height = "160px";
        setTimeout(function () {
            document.getElementById("serch_form").style.opacity = 1;
            document.getElementById("serch_form").style.visibility = "visible";
        } , 400)
    }
}
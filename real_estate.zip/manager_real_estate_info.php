<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>مشاور املاک نجاتی</title>
    <link href="bootstrap-5.3.0-dist/css/bootstrap.min.css"
          rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM"
          crossorigin="anonymous">
    <link href="fontawesome-free-6.4.0-web/css/fontawesome.css" rel="stylesheet">
    <link href="fontawesome-free-6.4.0-web/css/brands.css" rel="stylesheet">
    <link href="fontawesome-free-6.4.0-web/css/solid.css" rel="stylesheet">
    <link href="css/index.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/pannellum.css">
    <script type="text/javascript" src="js/pannellum.js"></script>
    <link href="css/real_estate_info.css" rel="stylesheet" type="text/css">
</head>

<body>

<header>
    <?php
    require ('header_manager.inc');
    ?>
</header>

<main id="main_real_estate_info">
    <div class="images" id="images">
        <div>
            <form>
                <button>
                    حال
                </button>
            </form>
            <form>
                <button>
                    اتاق اول
                </button>
            </form>
            <form>
                <button>
                    اتاق دوم
                </button>
            </form>
            <form>
                <button>
                    اتاق سوم
                </button>
            </form>
            <form>
                <button>
                    آشپز خانه
                </button>
            </form>
            <form>
                <button>
                    حیاط
                </button>
            </form>
        </div>
        <div id="panorama" class="my_panorama">
        </div>
    </div>
    <div id="info">
        <span>
            خانه ویلایی زیبا در بلوار جمهوری
            <button class="btn btn-primary" style="float: left; margin-left: 30px; font-family: 'B Titr'">
                اطلاعات مالک
            </button>
            <button class="btn btn-primary" style="float: left; margin-left: 30px; font-family: 'B Titr'">
                ویرایش اطلاعات
            </button>
        </span>
        <fieldset>
            <legend>
                اطلاعات کلی
            </legend>
            <div>
                <section>
                    <i class="fa-solid fa-sack-dollar"></i>
                    قیمت:
                </section>
                <section>
                    2000000000 تومان
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-building"></i>
                    نوع:
                </section>
                <section>
                    آپارتمانی
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-file-lines"></i>
                    نوع معامله:
                </section>
                <section>
                    رهن و اجاره
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-map"></i>
                    مساحت:
                </section>
                <section>
                    200 متر مربع
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-house"></i>
                    تعداد اتاق:
                </section>
                <section>
                    4 عدد
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-clock-rotate-left"></i>
                    سال ساخت:
                </section>
                <section>
                    1395
                </section>
            </div>
        </fieldset>

        <fieldset>
            <legend>
                <i class="fa-solid fa-location-dot"></i>
                آدرس
            </legend>
            <div>
                <section>
                    <i class="fa-solid fa-road"></i>
                    خیابان:
                </section>
                <section>
                    12 فروردین
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-road"></i>
                    کوچه:
                </section>
                <section>
                    اول
                </section>
            </div>
            <div>
                <section>
                    <svg width="20" height="20" fill="currentColor" class="bi bi-7-square-fill" viewBox="0 0 16 16" style="margin-left: 4px">
                        <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2Zm3.37 5.11V4.001h5.308V5.15L7.42 12H6.025l3.317-6.82v-.07H5.369Z"/>
                    </svg>
                    پلاک:
                </section>
                <section>
                    15
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-regular fa-building"></i>
                    طبقه:
                </section>
                <section>
                    دوم
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-building-user"></i>
                    واحد:
                </section>
                <section>
                    8
                </section>
            </div>
        </fieldset>
        <fieldset>
            <legend>
                <i class="fa-solid fa-list-ul"></i>
                امکانات
            </legend>
            <div>
                <section>
                    <i class="fa-solid fa-square-parking"></i>
                    پارکینگ:
                </section>
                <section>
                    دارد
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-elevator"></i>
                    آسانسور:
                </section>
                <section>
                    دارد
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-fire-extinguisher"></i>
                    سیستم ضد حریق:
                </section>
                <section>
                    دارد
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-bell"></i>
                    آیفون تصویری:
                </section>
                <section>
                    دارد
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-person-swimming"></i>
                    استخر:
                </section>
                <section>
                    دارد
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-warehouse"></i>
                    انباری:
                </section>
                <section>
                    دارد
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-phone"></i>
                    تلفن:
                </section>
                <section>
                    دارد
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-fan"></i>
                    کولر:
                </section>
                <section>
                    دارد
                </section>
            </div>
            <div>
                <section>
                    <i class="fa-solid fa-door-open"></i>
                    درب ریموت کنترل:
                </section>
                <section>
                    دارد
                </section>
            </div>
        </fieldset>
    </div>

</main>

<footer>

</footer>
<script>
    pannellum.viewer('panorama', {
        "type": "equirectangular",
        "panorama": "./image/main_picture.jpg",
        "autoLoad": true,
        "autoRotate": -3,
        "compass": true,
        "autoRotateInactivityDelay" : 4000,
        "northOffset": 0,
    });
</script>
<script src="js/real_estate_info.js"></script>
<script src="js/header_menu.js"></script>
</body>



</html>



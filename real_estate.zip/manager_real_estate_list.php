<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>مشاور املاک نجاتی</title>
    <link href="bootstrap-5.3.0-dist/css/bootstrap.min.css"
          rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM"
          crossorigin="anonymous">
    <link href="fontawesome-free-6.4.0-web/css/fontawesome.css" rel="stylesheet">
    <link href="fontawesome-free-6.4.0-web/css/brands.css" rel="stylesheet">
    <link href="fontawesome-free-6.4.0-web/css/solid.css" rel="stylesheet">
    <link href="css/index.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/pannellum.css">
    <script type="text/javascript" src="js/pannellum.js"></script>
    <link href="css/real_estate_list.css" rel="stylesheet" type="text/css">
</head>

<body>

<header>
    <?php
    require ('header_manager.inc');
    ?>
</header>

<main id="main_real_estate_list">
    <div class="under_list" id="under_list">
        <span id="btn_serch">
            <i class="fa-solid fa-chevron-down fa-rotate-90" style="transition: 0.3s" id="icon_serch"></i>
            &nbsp;
            جست و جو
        </span>
        <form id="serch_form">
            <div>
                <label for="s_title">عنوان:</label>
                &nbsp;
                <input type="text" name="title" id="s_title" class="form-control"
                style="width: 250px">
            </div>
            <div>
                <label for="address">آدرس:</label>
                &nbsp;
                <input type="text" name="address" id="address" class="form-control"
                       style="width: 300px">
            </div>
            <div>
                <label for="number_room">تعداد اتاق:</label>
                &nbsp;
                <input type="number" name="number_room" id="number_room" class="form-control"
                min="0" style="width: 55px; padding-left: 0">
            </div>
            <div>
                <label for="number_room">نوع:</label>
                &nbsp;
                <select class="form-select" style="height: 30px; line-height: 30px; float: right;
                    width: 110px; margin-right: 5px; padding-top: 0; padding-bottom: 0;" name="type"
                    id="type">
                    <option selected>همه</option>
                    <option value="1">آپارتمانی</option>
                    <option value="2">ویلایی</option>
                    <option value="3">زمین</option>
                </select>
            </div>
            <div>
                <label for="number_room">نوع معامله:</label>
                &nbsp;
                <select class="form-select" style="height: 30px; line-height: 30px; float: right;
                    width: 120px; margin-right: 5px; padding-top: 0; padding-bottom: 0;" name="transaction_type"
                    id="transaction_type">
                    <option selected>همه</option>
                    <option value="1">خرید</option>
                    <option value="2">رهن و اجاره</option>
                </select>
            </div>
            <div>
                <label for="min_area">حداقل مساحت:</label>
                &nbsp;
                <input type="min_area" name="min_area" id="min_area" class="form-control"
                       min="0" style="width: 70px; padding-left: 0">
            </div>
            <div>
                <label for="max_area">حداکثر مساحت:</label>
                &nbsp;
                <input type="number" name="max_area" id="max_area" class="form-control"
                       min="0" style="width: 70px; padding-left: 0">
            </div>
            <div>
                <label for="min_money">حداقل مبلغ:</label>
                &nbsp;
                <input type="min_money" name="min_money" id="min_area" class="form-control"
                       min="0" style="width: 70px; padding-left: 0">
            </div>
            <div>
                <label for="max_money">حداکثر مبلغ:</label>
                &nbsp;
                <input type="number" name="max_money" id="max_money" class="form-control"
                       min="0" style="width: 70px; padding-left: 0">
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="1" id="elevator" name="elevator"
                style="height: 16px; margin-top: 7px">
                <label class="form-check-label" for="elevator">
                    آسانسور
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="1" id="cold" name="cold"
                       style="height: 16px; margin-top: 7px">
                <label class="form-check-label" for="cold">
                    کولر
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="1" id="heating" name="heating"
                       style="height: 16px; margin-top: 7px">
                <label class="form-check-label" for="heating">
                    شوفاژ
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="1" id="phone" name="phone"
                       style="height: 16px; margin-top: 7px">
                <label class="form-check-label" for="phone">
                    تلفن
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="1" id="parking" name="parking"
                       style="height: 16px; margin-top: 7px">
                <label class="form-check-label" for="parking">
                    پارکینگ
                </label>
            </div>
            <button type="submit" class="btn btn-primary">
                جست و جو
            </button>
        </form>
    </div>

    <hr style="z-index: 0">

    <div id="real_estate_list">
        <div>
            <div>
                <span>
                    خانه ویلایی در خیابان خرمشهر
                </span>
                <span>
                    نوع: آپارتمانی
                </span>
                <span>
                    طبقه: سوم
                </span>
                <span>
                    واحد: 15
                </span>
                <span>
                    تعداد اتاق: 3
                </span>
                <span>
                    استخر: ندارد
                </span>
                <span>
                    دوبلکس: نیست
                </span>
                <span>
                    سیستم اتفای حریق: دارد
                </span>
                <span>
                    مساحت: 300 مترمربع
                </span>

            </div>
            <div id="panorama1" class="my_panorama">
            </div>
            <script>
                pannellum.viewer('panorama1', {
                    "type": "equirectangular",
                    "panorama": "./image/main_picture.jpg",
                    "autoLoad": true,
                    "autoRotate": -3,
                    "autoRotateInactivityDelay" : 4000,
                    "northOffset": 0,
                });
            </script>
        </div>
        <div>
            <div>
                <span>
                    خانه ویلایی در خیابان خرمشهر
                </span>
                <span>
                    نوع: آپارتمانی
                </span>
                <span>
                    طبقه: سوم
                </span>
                <span>
                    واحد: 15
                </span>
                <span>
                    تعداد اتاق: 3
                </span>
                <span>
                    استخر: ندارد
                </span>
                <span>
                    دوبلکس: نیست
                </span>
                <span>
                    سیستم اتفای حریق: دارد
                </span>
                <span>
                    مساحت: 300 مترمربع
                </span>

            </div>
            <div id="panorama2" class="my_panorama">
            </div>
            <script>
                pannellum.viewer('panorama2', {
                    "type": "equirectangular",
                    "panorama": "./image/main_picture.jpg",
                    "autoLoad": true,
                    "autoRotate": -3,
                    "autoRotateInactivityDelay" : 4000,
                    "northOffset": 0,
                });
            </script>
        </div>
        <div>
            <div>
                <span>
                    خانه ویلایی در خیابان خرمشهر
                </span>
                <span>
                    نوع: آپارتمانی
                </span>
                <span>
                    طبقه: سوم
                </span>
                <span>
                    واحد: 15
                </span>
                <span>
                    تعداد اتاق: 3
                </span>
                <span>
                    استخر: ندارد
                </span>
                <span>
                    دوبلکس: نیست
                </span>
                <span>
                    سیستم اتفای حریق: دارد
                </span>
                <span>
                    مساحت: 300 مترمربع
                </span>

            </div>
            <div id="panorama3" class="my_panorama">
            </div>
            <script>
                pannellum.viewer('panorama3', {
                    "type": "equirectangular",
                    "panorama": "./image/main_picture.jpg",
                    "autoLoad": true,
                    "autoRotate": -3,
                    "autoRotateInactivityDelay" : 4000,
                    "northOffset": 0,
                });
            </script>
        </div>
        <div>
            <div>
                <span>
                    خانه ویلایی در خیابان خرمشهر
                </span>
                <span>
                    نوع: آپارتمانی
                </span>
                <span>
                    طبقه: سوم
                </span>
                <span>
                    واحد: 15
                </span>
                <span>
                    تعداد اتاق: 3
                </span>
                <span>
                    استخر: ندارد
                </span>
                <span>
                    دوبلکس: نیست
                </span>
                <span>
                    سیستم اتفای حریق: دارد
                </span>
                <span>
                    مساحت: 300 مترمربع
                </span>

            </div>
            <div id="panorama4" class="my_panorama">
            </div>
            <script>
                pannellum.viewer('panorama4', {
                    "type": "equirectangular",
                    "panorama": "./image/main_picture.jpg",
                    "autoLoad": true,
                    "autoRotate": -3,
                    "autoRotateInactivityDelay" : 4000,
                    "northOffset": 0,
                });
            </script>
        </div>
        <div>
            <div>
                <span>
                    خانه ویلایی در خیابان خرمشهر
                </span>
                <span>
                    نوع: آپارتمانی
                </span>
                <span>
                    طبقه: سوم
                </span>
                <span>
                    واحد: 15
                </span>
                <span>
                    تعداد اتاق: 3
                </span>
                <span>
                    استخر: ندارد
                </span>
                <span>
                    دوبلکس: نیست
                </span>
                <span>
                    سیستم اتفای حریق: دارد
                </span>
                <span>
                    مساحت: 300 مترمربع
                </span>

            </div>
            <div id="panorama5" class="my_panorama">
            </div>
            <script>
                pannellum.viewer('panorama5', {
                    "type": "equirectangular",
                    "panorama": "./image/main_picture.jpg",
                    "autoLoad": true,
                    "autoRotate": -3,
                    "autoRotateInactivityDelay" : 4000,
                    "northOffset": 0,
                });
            </script>
        </div>
        <div>
            <div>
                <span>
                    خانه ویلایی در خیابان خرمشهر
                </span>
                <span>
                    نوع: آپارتمانی
                </span>
                <span>
                    طبقه: سوم
                </span>
                <span>
                    واحد: 15
                </span>
                <span>
                    تعداد اتاق: 3
                </span>
                <span>
                    استخر: ندارد
                </span>
                <span>
                    دوبلکس: نیست
                </span>
                <span>
                    سیستم اتفای حریق: دارد
                </span>
                <span>
                    مساحت: 300 مترمربع
                </span>

            </div>
            <div id="panorama6" class="my_panorama">
            </div>
            <script>
                pannellum.viewer('panorama6', {
                    "type": "equirectangular",
                    "panorama": "./image/main_picture.jpg",
                    "autoLoad": true,
                    "autoRotate": -3,
                    "autoRotateInactivityDelay" : 4000,
                    "northOffset": 0,
                });
            </script>
        </div>
    </div>
</main>

<footer>

</footer>

<script src="js/real_estate_list.js"></script>
<script src="js/header_menu.js"></script>
</body>



</html>


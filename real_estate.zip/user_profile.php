<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>مشاور املاک نجاتی</title>
    <link href="bootstrap-5.3.0-dist/css/bootstrap.min.css"
          rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM"
          crossorigin="anonymous">
    <link href="fontawesome-free-6.4.0-web/css/fontawesome.css" rel="stylesheet">
    <link href="fontawesome-free-6.4.0-web/css/brands.css" rel="stylesheet">
    <link href="fontawesome-free-6.4.0-web/css/solid.css" rel="stylesheet">
    <link href="css/index.css" rel="stylesheet" type="text/css">
    <link href="css/manager_profile.css" rel="stylesheet" type="text/css">
</head>

<body>

<?php
require ('functions/functions.inc');

if (!isset($_COOKIE['fname']))
{
    redirect('error_log.php');
}
if ( $_COOKIE['level'] != 0 && $_COOKIE['level'] != 1 )
{
    redirect('error_access.php');
}

$pdo = require_once('connections/profile_manager.inc');
require('functions/profile_manager_database.inc');

if (isset($_POST['username']))
{
    $user['id'] = $_POST['id'];
    $user['username'] = $_POST['username'];
    $user['fname'] = $_POST['fname'];
    $user['lname'] = $_POST['lname'];
    $user['phone'] = $_POST['phone'];
    $user['gender'] = $_POST['gender'];
    $user['password'] = null;
    $user['level'] = $_POST['level'];
    if (isset($_POST['password']))
    {
        $user['password'] = $_POST['password'];
    }
    $result = change_info_user ( $pdo , $user );
    if ($result == 0)
    {
        $user = get_user( $pdo , $_POST['id'] );
        echo "
        <div class='massage success' id='alert'>
            اطلاعات با موفقیت ویرایش شد.
        </div>
        ";
        echo "
        <script>
            setTimeout( function () {
                document.getElementById('alert').style.opacity = 0;
                document.getElementById('alert').style.visibility = 'hidden';
            } , 3000);
        </script>
        ";
    }
    elseif ($result == 1 )
    {
        echo "
        <div class='massage danger' id='alert'>
            نام کاربری قبلا ثبت شده است!
        </div>
        ";
        echo "
        <script>
            setTimeout( function () {
                document.getElementById('alert').style.opacity = 0;
                document.getElementById('alert').style.visibility = 'hidden';
            } , 3000);
        </script>
        ";
    }
    elseif ($result == 2 )
    {
        echo "
        <div class='massage danger' id='alert'>
            شماره همراه قبلا ثبت شده است!
        </div>
        ";
        echo "
        <script>
            setTimeout( function () {
                document.getElementById('alert').style.opacity = 0;
                document.getElementById('alert').style.visibility = 'hidden';
            } , 3000);
        </script>
        ";
    }
}
?>

<header>
    <?php
    require ('header_manager.inc');
    ?>
</header>

<?php

if (isset($_POST['id_user']))
{
    $user = get_user ( $pdo , $_POST['id_user'] );
    $fname = $user['first_name'];
    $lname = $user['last_name'];
    $phone = $user['phone'];
    $username = $user['user_name'];
    $id = $user['id'];
    $gender = $user['gender'];
    $level = $_COOKIE['level'];
    if ($gender == 'male')
    {
        $gender = 'مرد';
    }
    else
    {
        $gender = 'زن';
    }
}
else
{
    $fname = $_COOKIE['fname'];
    $lname = $_COOKIE['lname'];
    $phone = $_COOKIE['phone'];
    $username = $_COOKIE['username'];
    $id = $_COOKIE['id'];
    $gender = $_COOKIE['gender'];
    $level = $_COOKIE['level'];
    if ($gender == 'male')
    {
        $gender = 'مرد';
    }
    else
    {
        $gender = 'زن';
    }
}

?>

<main id="main_manager_profile">
    <div class="profile">
        <?php
        echo "
        <section>
            <i class='fa-solid fa-circle-user'></i>
            <div style='font-size: 18pt; line-height: 25px'>
            ID:
            &nbsp;
            $id
            </div>
            <button class='btn btn-primary' id='btn_change_info'>
                ویرایش اطلاعات
            </button>
        </section>
        <div>
            نام:
            &nbsp;
            $fname
        </div>
        <div>
            نام خانوادگی:
            &nbsp;
            $lname
        </div>
        <div>
            جنسیت:
            &nbsp;
            $gender
        </div>
        <div>
            شماره تماس:
            &nbsp;
            $phone
        </div>
        <div>
            نام کاربری:
            &nbsp;
            $username
        </div>
        ";
        ?>


    </div>
</main>

<footer>

</footer>


<div id="change_info">
    <div>
        <span>
            ویرایش اطلاعات
        </span>
        <section id="exit_change_info">
            <i class="fa-solid fa-xmark"></i>
        </section>

        <form class="was-validated" method="post" action="user_profile.php">
            <?php
            echo "
            <div>
                <span class='input-group-text' id='basic-addon1'>نام کاربری:</span>
                <input type='text' class='form-control' placeholder='Username'
                       aria-label='Username' aria-describedby='basic-addon1' required
                       minlength='3' maxlength='16' value='$username'
                       pattern='[A-Za-z]+[A-Za-z0-9]{3,16}' name='username'
                       title='نام کاربری با حروف انگلیسی شروع شده و شامل حروف کوچک و بزرگ انگلیسی و اعداد می باشد.'>
                <div class='invalid-feedback'>
                    نام کاربری را وارد کنید.
                </div>
            </div>
            <div>
                <span class='input-group-text' id='basic-addon1'>رمز عبور:</span>
                <input type='password' class='form-control' placeholder='Password'
                       aria-label='Password' aria-describedby='basic-addon1'
                       minlength='3' maxlength='16'
                       pattern='[A-Za-z0-9]{3,16}' name='password'>
                <div class='invalid-feedback'>
                    رمز عبور را وارد کنید.
                </div>
            </div>
            <div>
                <span class='input-group-text' id='basic-addon1'>نام:</span>
                <input type='text' class='form-control' placeholder='First Name'
                       aria-label='Username' aria-describedby='basic-addon1'
                       minlength='3' maxlength='16' value='$fname'
                       name='fname' required>
                <div class='invalid-feedback'>
                    نام را وارد کنید.
                </div>
            </div>
            <div>
                <span class='input-group-text' id='basic-addon1'>نام خانوادگی:</span>
                <input type='text' class='form-control' placeholder='Last name'
                       aria-label='Username' aria-describedby='basic-addon1'
                       minlength='3' maxlength='16' value='$lname'
                       name='lname' required>
                <div class='invalid-feedback'>
                    نام خانوادگی را وارد کنید.
                </div>
            </div>
            <div>
                <span class='input-group-text' id='basic-addon1'>شماره همراه:</span>
                <input type='tel' class='form-control' placeholder='Phone Number'
                       aria-label='Number' aria-describedby='basic-addon1'
                       minlength='3' maxlength='16' value='$phone'
                       pattern='[0-9]{11}' name='phone' required>
                <div class='invalid-feedback'>
                    شماره همراه را وارد کنید.
                </div>
            </div>
            <div>
                <span class='input-group-text' id='basic-addon1'>جنسیت:</span>
                <div class='form-check' style='margin-right: 25px; color: black; margin-top: 5px; transition: 0.2s'>
                    <input class='form-check-input' type='radio' name='gender'
                           id='gender1' checked value='male' style='transition: 0.4s'>
                    <label class='form-check-label' for='gender1' style='color: black'>
                        مرد
                    </label>
                </div>
                <div class='form-check' style='margin-right: 20px; color: black; margin-top: 5px; transition: 0.2s'>
                    <input class='form-check-input' type='radio' name='gender' id='gender2'
                           style='transition: 0.4s' value='female'>
                    <label class='form-check-label' for='gender2' style='color: black'>
                        زن
                    </label>
                </div>
                <div class='invalid-feedback'>
                    جنسیت را انتخاب کنید.
                </div>
            </div>
            <div>
                <span class='input-group-text' id='basic-addon1'>عکس:</span>
                <input type='file' class='form-control'
                       aria-describedby='basic-addon1'
                       name='image'>
            </div>
            <input type='hidden' value='$id' name='id'>
            <input type='hidden' value='$level' name='level'>
            ";
            if (isset($_POST['id_user']))
            {
                echo "
                <input type='hidden' value='$id' name='id_user'>
                ";
            }
            ?>

            <button type="submit" class="btn btn-primary">
                ویرایش
            </button>
        </form>
    </div>
</div>


<script src="js/manager_profile.js"></script>
<script src="js/header_menu.js"></script>
</body>

<?php
if (isset($_POST['username']))
{
    if ($result == 0)
    {
        $id = $_POST['id'];
        echo "
        <form style='display: none' method='post' action='user_profile.php'>
            <input type='hidden' name='id_user' value='$id'>
            <input type='submit' id='send' style='display: none'>
        </form>
        <script>
            function clickin(){
                document.getElementById('send').click()
            }
            setTimeout('clickin()',3000);
        </script>
        ";
    }
}
?>


</html>


